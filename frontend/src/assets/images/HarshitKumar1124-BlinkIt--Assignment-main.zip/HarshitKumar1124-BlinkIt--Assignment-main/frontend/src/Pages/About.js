import React from 'react'
import Navbar from '../Components/Navbar/Navbar'

const About = () => {
  return (
    <div>
        <Navbar/>
        <h1 style={{padding:"5rem"}}>This page is not developed as it was not the mentioned task</h1>
    </div>
  )
}

export default About